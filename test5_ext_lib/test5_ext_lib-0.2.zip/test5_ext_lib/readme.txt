#create zip archive:
zip -x \*/.git/\* -r test5_ext_lib.zip test5_ext_lib
